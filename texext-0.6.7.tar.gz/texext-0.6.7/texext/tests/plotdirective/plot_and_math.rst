############################
Plot directive with mathcode
############################

Some text

.. plot::
    :context:
    :nofigs:
    :include-source: true

    a = 101

More text

.. mathcode::

    a
