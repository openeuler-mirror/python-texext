# -*- coding: utf-8 -*-
extensions = [
    'sphinx.ext.mathjax',
    'texext.mathcode',
    'texext.math_dollar']

# The master toctree document.
master_doc = 'index'
