# Test project for texext sphinx extensions using plot_directive

A tiny sphinx project from ``sphinx-quickstart`` with all default answers.
